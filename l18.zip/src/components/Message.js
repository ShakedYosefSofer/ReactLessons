// rfc

import React from 'react'

export default function Message(props) {
  return (
    <div>
      <h2>Message: {props.txt}</h2>
    </div>
  )
}

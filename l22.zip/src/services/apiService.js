// נייצר משתנה של היו אר אל של השרת לבקשות איי פי איי
// כך שאם נרצה לדבר עם השרת האמיתי נוכל להחליף אותו בקלות
export const API_URL = "http://localhost:3001";
// export const API_URL = "http://monkeys.co.il";